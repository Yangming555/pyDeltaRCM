from . import preprocessor

if __name__ == '__main__':
    preprocessor.preprocessor_wrapper()
