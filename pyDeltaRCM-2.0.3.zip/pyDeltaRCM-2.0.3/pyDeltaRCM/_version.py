
def __version__():
    """
    Private version declaration, gets assigned to pyDeltaRCM.__version__
    during import
    """
    return '2.0.3'
