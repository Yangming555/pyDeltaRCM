************
License
************

This project is licensed under the MIT License - see the `full license <https://github.com/DeltaRCM/pyDeltaRCM/blob/develop/LICENSE>`_  file for details. 
It is provided without warranty or guaranteed support.
