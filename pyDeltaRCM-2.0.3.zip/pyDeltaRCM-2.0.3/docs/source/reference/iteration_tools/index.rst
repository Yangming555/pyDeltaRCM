.. api.iteration_tools:

***************
iteration_tools
***************

.. currentmodule:: pyDeltaRCM.iteration_tools

.. todo::

    Add paragraph description of the module. What stages are defined here generally? Make a table with the main ones like in water tools?


Public API methods attached to model
------------------------------------

The following methods are defined in the ``iteration_tools`` class, of the ``pyDeltaRCM.iteration_tools`` module. 

.. autosummary::

    iteration_tools

.. autoclass:: iteration_tools
