*********************************
hook_tools
*********************************

.. currentmodule:: pyDeltaRCM.hook_tools

.. todo::

    Add paragraph description of the module. What stages are defined here generally? Link to relevant documentation about hooks in user guide and model list.


Public API methods attached to model
------------------------------------

The following methods are defined in the ``hook_tools`` class, of the ``pyDeltaRCM.hook_tools`` module. 

.. autosummary::

    hook_tools

.. autoclass:: hook_tools
